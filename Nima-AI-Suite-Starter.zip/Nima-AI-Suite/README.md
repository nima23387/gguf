# Nima AI Suite

نسخه آغازین پروژه برای Xperia X8 / Android 2.3.7.

## امکانات فعلی
- بررسی اطلاعات حافظه از `/proc/meminfo`
- نمایش وضعیت Swap از `/proc/swaps`
- بررسی دسترسی root
- انتخاب فایل و بررسی سرآیند اولیه GGUF (magic، version، tensor count، metadata count)
- رابط فارسی راست‌چین و بدون نیاز به اینترنت در زمان اجرا

## محدودیت‌های صادقانه نسخه 0.1.0
- RAM Booster هنوز Swap را فعال یا ایجاد نمی‌کند.
- GGUF Compiler در این نسخه فقط فایل را بررسی می‌کند؛ کوانتیزه‌سازی/تبدیل انجام نمی‌دهد.
- GGUF Runner هنوز موتور inference ندارد؛ بنابراین ادعای اجرای مدل نمی‌کند.
- سازگاری کامل فارسی در همه نسخه‌های رام باید روی Xperia X8 واقعی آزمایش شود.
- اجرای مدل زبانی روی ARMv6 و حافظه محدود X8 ممکن است بسیار کند یا غیرممکن باشد.

## ساخت با GitHub
فایل `.github/workflows/build.yml` با push به شاخه main/master یا اجرای دستی، APK آزمایشی می‌سازد.
پس از موفقیت، از بخش Actions وارد اجرای workflow شوید و artifact با نام `Nima-AI-Suite-debug` را دریافت کنید.

## تنظیمات
- applicationId: `com.nima.aisuite`
- minSdkVersion: 7
- targetSdkVersion: 10
- compileSdkVersion: 28
- Android Gradle Plugin: 3.5.4
- Gradle: 5.6.4
- JDK: 8
